export declare function Tokens(): import("react/jsx-runtime").JSX.Element;
