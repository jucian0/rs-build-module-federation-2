export declare function Apps(): import("react/jsx-runtime").JSX.Element;
