export declare function List(): import("react/jsx-runtime").JSX.Element;
