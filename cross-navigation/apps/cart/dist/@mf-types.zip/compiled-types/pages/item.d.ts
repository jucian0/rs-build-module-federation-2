export declare function Item(): import("react/jsx-runtime").JSX.Element;
