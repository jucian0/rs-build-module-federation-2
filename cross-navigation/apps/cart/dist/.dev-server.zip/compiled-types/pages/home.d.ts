export declare function Home(): import("react/jsx-runtime").JSX.Element;
