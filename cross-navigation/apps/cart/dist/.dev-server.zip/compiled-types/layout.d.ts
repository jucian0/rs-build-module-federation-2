export declare function Layout(): import("react/jsx-runtime").JSX.Element;
